# ONEDGE-SDK Specification Bundle

Generated: 2026-02-25T21:00:43.483199Z

Contents:
- docs/SPECIFICATION.md (v1.1.0-rc2 baseline)
- docs/SECURITY_MODEL.md (v1.0, normative)
- docs/RUNTIME_ABI.md (v1.0, normative)
- docs/CRYPTO_DOMAINS.md (v1.0, normative)
- docs/XAM.md (v1.0, normative)

Note:
- If your repository has an updated `SPECIFICATION.md` beyond v1.1.0-rc2, replace the included baseline with your canonical file.
