# ONEDGE-SDK — Security Model
**Status:** Draft (Normative)  
**Applies to:** ONEDGE-SDK Client + Runtime Boundary, Physics Firewall, XAM  
**Version:** 1.0

## 1. Scope
This document specifies:
- Threat model and trust assumptions.
- Security invariants that implementations MUST uphold.
- Attack surfaces and required mitigations.

Non-goals:
- Full formal verification of the Runtime.
- Disclosure of proprietary circuits or STF internals.

## 2. Terminology
- **Client:** Native Rust node binary (p2p, storage, mempool, executor).
- **Runtime:** Deterministic RISC-V blob defining the State Transition Function (STF).
- **Extrinsic:** Signed input committed to the block (telemetry, market actions).
- **Receipt:** Verifiable output of Runtime execution (events + commitments + proofs).
- **Golden Record:** State root commitment (NOMT) for audit and replay.

## 3. Trust Assumptions
### 3.1 Trust-Minimized Components
The following components MUST be verifiable by third parties:
- Runtime determinism given identical inputs.
- State root correctness (NOMT commitments).
- Signature validity for extrinsics and messages.
- Proof verification correctness (ZK verifier; statement-level).

### 3.2 Trusted Components (Explicit)
- Telemetry provenance MAY rely on hardware attestation (TPM/HSM/TEE), when enabled.
- Physical sensors and their calibration MAY be trusted within defined tolerances.
- Governance keys are trusted to authorize Runtime upgrades.

## 4. Adversary Classes
- **A1 — Network Adversary:** Packet dropping, reordering, replay, eclipse attempts, spam.
- **A2 — Market Actor Adversary:** Submits economically favorable extrinsics attempting to violate physical invariants.
- **A3 — Asset Operator Adversary:** Attempts to falsify telemetry; sensor spoofing.
- **A4 — Node Operator Adversary:** Modifies local binaries; attempts to run altered Runtime/Client.
- **A5 — Governance Key Compromise:** Malicious Runtime upgrade issuance.

## 5. Security Invariants (MUST)
### I1 — Determinism Invariant
Given identical prior state root, ordered extrinsics, and Runtime code hash, the Runtime MUST produce identical post-state roots and receipts, and identical proof verification outcomes for the same `(vk_id, statement_id)` (and/or proof commitments) when proofs are present.

### I2 — No Side-Effect Invariant (Runtime)
The Runtime MUST NOT access wall-clock time, network IO, filesystem, or nondeterministic RNG. All external data MUST enter via extrinsics or deterministic host functions.

### I3 — State Commitment Invariant
Every state transition MUST be committed to a verifiable state root (NOMT). Clients MUST reject blocks whose post-state root mismatches Runtime output.

### I4 — Physics Firewall Invariant
Any extrinsic implying a state transition that violates physical constraints MUST be rejected via direct constraint checking AND/OR zero-knowledge proof verification.

### I5 — Replay Protection Invariant (XAM)
XAM messages MUST be replay-protected by nonce + expiry. Destination runtimes MUST keep persistent nonce tables.

### I6 — Upgrade Authorization Invariant
Runtime upgrades MUST be gated by threshold policies defined at the Client layer. Clients MUST refuse unauthorized code updates.

### I7 — Bounded-Cost Execution Invariant (Anti-DoS)
No operation in the mempool admission phase (`validate_transaction`) MAY perform unbounded work. Heavy cryptographic proof verification MUST be deferred to block execution (`apply_extrinsic`) or strictly rate-limited to prevent DoS via computational exhaustion.

## 6. Attack Surface Map and Required Mitigations

### 6.1 Network Layer (libp2p)
Threats: spam floods, eclipse, gossipsub amplification, replay.
Mitigations:
- Nodes SHOULD enforce peer scoring and connection limits.
- Implementations MUST enforce message size limits *before* allocation.
- Implementations SHOULD rate-limit per peer and per topic.

### 6.2 Mempool / Admission
Threats: malformed codec, oversized vectors, signature abuse, computational DoS.
Mitigations:
- DATA codec MUST enforce maximum lengths and recursion bounds.
- Signature checks SHOULD be performed before any expensive verification.
- Invariant I7 applies: expensive proof verification MUST be deferred or strictly rate-limited.

### 6.3 Telemetry Ingestion
Threats: spoofed telemetry, stale values, withheld updates.
Mitigations:
- Telemetry extrinsics MUST include expiry (block-based) and freshness markers.
- When enabled, telemetry MUST be signed by attested keys (TPM/HSM/TEE).
- Runtime MUST reject telemetry outside configured staleness bounds (`ERR_TELEMETRY_STALE`).

### 6.4 Runtime Upgrade Governance
Threats: malicious code injection, downgrade attacks.
Mitigations:
- Client MUST gate `set_code` behind threshold authorization.
- Client SHOULD support emergency rollback to a prior approved code hash.
- Clients SHOULD maintain an allowlist of approved runtime code hashes per `spec_version`.

## 7. Auditability Requirements
Implementations MUST provide a way to replay blocks deterministically, event log commitments, and exportable proofs per relevant dispatch.

## 8. References
- `SPECIFICATION.md` (Core Architecture & Physics Firewall)
- `RUNTIME_ABI.md` (Bounded-cost rules & Reason Codes)
- `CRYPTO_DOMAINS.md` (Cryptographic separation)
- `XAM.md` (Cross-Asset Messaging mitigations)
