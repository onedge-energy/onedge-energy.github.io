# ONEDGE-SDK — XAM Protocol Specification
**Status:** Draft (Normative)  
**Version:** 1.0  
**Transport:** libp2p gossipsub (default)

## 1. Goal
Enables asynchronous, trustless coordination between nodes running distinct runtimes, preserving replay protection, ordering, and auditability.

## 2. Message Types
**XAM Envelope (Canonical):**
`[src_runtime_id, dst_runtime_id, src_node_id, nonce, expiry_block, payload_commitment, payload, signature]`

**Payload Classes:** `LockIntent`, `ExecuteRequest`, `ExecuteReceipt`, `Cancel`.

## 3. Validation Rules (MUST)
Destination MUST:
1. Check `dst_runtime_id`.
2. Check `expiry_block >= current_block`.
3. Verify signature domain `ONEDGE-SDK/v1/Sig/XAM`.
4. Enforce size bounds. Implementations MUST enforce:
   - `payload` length <= `XAM_MAX_PAYLOAD_BYTES` (RECOMMENDED default: 64 KiB)
   - `signature` length <= 256 bytes
5. Enforce monotonic nonce. Nonce tracking MUST be keyed by `(src_node_id, src_runtime_id)` and persisted in state.
6. Record nonce acceptance in NOMT state.

## 4. Ordering Model
Strictly increasing nonces per `(src_node_id, src_runtime_id)`. Out-of-order buffering MUST be bounded by `XAM_REORDER_WINDOW` (implementation-defined, RECOMMENDED default: 32). Messages outside this window MUST be dropped.

## 5. Atomicity Model (Optimistic Receipts)
Source emits an intent -> Destination executes constrainted action -> Destination returns:
- `ExecuteReceipt::Success { receipt_commitment }` OR
- `ExecuteReceipt::Failure { reason_code, receipt_commitment }` (where `reason_code` MUST map to normative codes like `ERR_THERMAL_VIOLATION`).

**Rollback Semantics:** Source Runtime MUST treat `Failure` as a compensating action trigger (unlock capacity, update commitments).

## 6. Spam / DoS Controls (SHOULD)
Rate limits per peer; minimal fees/bonds for payload classes.

## 7. Auditability
Every accepted XAM message MUST correspond to a state update, an event commitment, and be replayable.

## 8. References
- `SPECIFICATION.md` (Cross-Asset Messaging Context)
- `RUNTIME_ABI.md` (Normative Reason Codes)
- `SECURITY_MODEL.md` (Replay Protection Invariant I5)
- `CRYPTO_DOMAINS.md` (Signature Domains)
