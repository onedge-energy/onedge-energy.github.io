# ONEDGE-SDK — Cryptographic Domains & Transcript Labels
**Status:** Draft (Normative)  
**Version:** 1.0  
**Curve:** Ristretto255 (Curve25519 group)

## 1. Purpose
Defines domain separation rules to prevent cross-protocol attacks (generator reuse, transcript collisions, type confusion).

## 2. Global Domain Tag
All transcript labels MUST be prefixed by: `ONEDGE-SDK/v1`

### 2.1 Hash and Hash-to-Group
- `H(·)` MUST be a cryptographic hash with 256-bit output (e.g., SHA3-256 or BLAKE2b-256).
- `H2G(·)` MUST be a standard hash-to-group mapping for Ristretto255 (e.g., Ristretto255 `hash_to_group` over a domain-separated hash stream).

## 3. Pedersen Commitment Generators
`C = x*G + r*H`
- `G = H2G("ONEDGE-SDK/v1/Pedersen/G")`
- `H = H2G("ONEDGE-SDK/v1/Pedersen/H")`

**Asset-Type Domains:**
Commitments MUST bind an asset-domain tag (e.g., `ONEDGE-SDK/v1/Asset/MWh`, `ONEDGE-SDK/v1/Asset/Tcell_celsius_q16`).

## 4. Fiat–Shamir Transcripts
### 4.1 Proof System Domain
Every proof transcript MUST include:
- `spec_version` (u32),
- `runtime_code_hash`,
- `state_root` (or block hash binding),
- global domain, proof system ID, and statement ID.

`pi_hash = H("ONEDGE-SDK/v1/PublicInputs" || encode(public_inputs))`

## 5. Signature Domains
- Extrinsics: `H("ONEDGE-SDK/v1/Sig/Extrinsic" || encode(extrinsic_body))`
- Telemetry: `H("ONEDGE-SDK/v1/Sig/Telemetry" || encode(telemetry))`
- XAM: `H("ONEDGE-SDK/v1/Sig/XAM" || encode(xam_message))`

## 6. Upgrade Safety
Domain label changes MUST be treated as consensus-breaking.

## 7. References
- `SPECIFICATION.md` (Cryptography Overview)
- `SECURITY_MODEL.md` (Replay protection & State Commitments)
