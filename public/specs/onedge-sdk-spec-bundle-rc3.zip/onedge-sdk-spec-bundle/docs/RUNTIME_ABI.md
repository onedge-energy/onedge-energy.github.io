# ONEDGE-SDK — Runtime ABI
**Status:** Draft (Normative)  
**Version:** 1.0  
**Target:** Deterministic RISC-V Runtime (no_std)

## 1. ABI Principles
1. The Runtime is a pure state transition function (STF) over `(State, Extrinsics) -> (State', Receipts)`.
2. All ABI entrypoints MUST be deterministic.
3. The ABI is stable across Client releases unless `spec_version` changes.

## 2. Types (Abstract)
- `Version { spec_version: u32, impl_version: u32, code_hash: [u8;32] }`
- `Extrinsic`, `Header`, `Validity`, `DispatchOutcome`, `Receipt`, `PhysicalState`, `ExchangeCert`.

### 2.1 Normative Reason Codes (Errors)
To ensure auditability, the Runtime MUST map execution failures to canonical reason codes within `Validity` and `DispatchOutcome`:
- `ERR_CODEC_INVALID`: The provided bytes failed canonical DATA decoding or violated bounds.
- `ERR_TELEMETRY_STALE`: Telemetry timestamp exceeds maximum allowed latency.
- `ERR_TELEMETRY_MISSING`: Required telemetry was not provided for validation or execution.
- `ERR_SOC_OUT_OF_BOUNDS`: Dispatch would violate State of Charge hardware limits.
- `ERR_THERMAL_VIOLATION`: Dispatch would violate temperature or ramp-rate constraints.
- `ERR_NONCE_REPLAY`: Extrinsic or XAM message nonce is <= last seen nonce.
- `ERR_PROOF_INVALID`: The provided ZKP failed cryptographic verification.
- `ERR_SIGNATURE_INVALID`: Ed25519/Sr25519 signature verification failed.

## 3. Canonical Entry Points

### 3.1 Core_version
`() -> Version`

### 3.2 validate_transaction
`(tx: Extrinsic) -> Validity`  
**Bounded-cost rule:** `validate_transaction` MUST complete in bounded time with bounded allocations. It MUST NOT perform full ZK proof verification except under strict local rate limits.

### 3.3 apply_extrinsic
`(ext: Extrinsic) -> DispatchOutcome`

### 3.4 finalize_block
`() -> Header`

### 3.5 execute_certificate
`(cert: ExchangeCert) -> Receipt`

### 3.6 validate_thermodynamic_state
`(state: PhysicalState) -> Result<(), Error>`

## 4. Host Functions (Normative Surface)
Host functions are the ONLY bridge to the Client and MUST preserve determinism.
- **Storage:** `storage_get`, `storage_set`, `storage_clear`, `storage_root`.
- **Crypto:** `ed25519_verify`, `sr25519_verify`, `sha3_256`, `blake2b_256`.
- **ZK Verification:** `zk_verify(proof, public_inputs, vk_id) -> bool`. Verification MUST be deterministic.
- **Randomness:** `random_seed() -> [u8;32]` MUST derive solely from chain state.

## 5. Compatibility and Versioning
Breaking changes to entrypoint signatures MUST bump `spec_version`. Clients MUST refuse to execute unsupported blobs.

## 6. References
- `SPECIFICATION.md` (Client vs Runtime execution)
- `SECURITY_MODEL.md` (Anti-DoS invariants & Bounded-Cost Execution)
