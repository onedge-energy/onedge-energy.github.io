# ONEDGE-SDK: Technical Specification & Architecture Reference

**Version:** 1.1.0-rc3 | **Classification:** Public / Open Architecture Specification  
**Maintainer:** IKKUNA SpA (Layer 0 Protocol)

## Table of Contents

1. Executive Overview  
2. Licensing & IP Boundary  
3. Core Architecture: Client vs. Runtime  
4. Determinism Contract  
5. Runtime ABI & Host Functions  
6. DATA Codec Specification  
7. Physics Firewall Specification  
8. Cryptography (Commitments & Proofs)  
9. XAM Protocol Overview  
10. Operations, Observability & Governance  
11. Module Extension Standard  

---

## 1. Executive Overview

The **ONEDGE-SDK** is a development framework built in Rust for deploying modular, high-performance, embedded verification nodes. It is the foundational codebase powering the ECME Kernel and the ONEDGE Decentralized Physical Infrastructure Network (DePIN).

The core design principle is the strict cryptographic separation of concerns ("Church & State"). This architecture enables physical assets (BESS, EV fleets) to execute multi-variable thermodynamic optimization algorithms while emitting Zero-Knowledge Proofs (ZKPs) guaranteeing physical constraints were not violated. By mathematically proving safe dispatch, the system reduces perceived operational risk, enabling a structurally lower cost of capital (WACC) for infrastructure financing.

## 2. Licensing & IP Boundary

To ensure ecosystem growth while protecting core business logic, the ONEDGE-SDK enforces a strict Intellectual Property boundary:

- **Open-Architecture (Public/FOSS):** Public interfaces, RPC definitions, Runtime ABI, network protocols (libp2p wrappers), cryptographic host function signatures, and boilerplate templates (`solo_node`).
- **Proprietary / Commercial License:** Specific State Transition Functions (STF) such as the **ECME Kernel Runtime**, proprietary Zero-Knowledge prover circuits, the internal implementation of the DATA Codec, and hardware-accelerated host functions.

## 3. Core Architecture: Client vs. Runtime

The SDK enforces a rigid boundary between the environment running the network and the environment defining market rules.

- **The Client (Outer Node):** The native Rust binary handling off-grid computational infrastructure (Networking, NOMT Storage, Mempool, RISC-V Executor). The Client is immutable during execution and **changes only via explicit, coordinated node upgrades / releases**.
- **The Runtime (Inner Logic):** The deterministic RISC-V binary blob containing the State Transition Function (STF). The Runtime is **upgraded on-chain / in-db via forkless upgrades** (e.g., `set_code` extrinsic), enabling zero-downtime market rule adaptations.

## 4. Determinism Contract

For the system to generate valid cryptographic proofs of thermodynamic state, the execution environment must be strictly deterministic. The RISC-V execution is deterministic under a constrained host interface.

**The Runtime Execution Rules:**

1. **No Wall-clock Time:** The Runtime cannot read system time. Time is strictly derived from the block timestamp extrinsic.
2. **No Network I/O:** The Runtime cannot perform HTTP/TCP calls. All external data (market prices, telemetry) must be explicitly committed via extrinsics.
3. **No Filesystem Access:** State is strictly mutated via the `p2pc_api` storage host functions (NOMT).
4. **No Nondeterministic RNG:** Randomness is only permitted if derived deterministically from the network state (e.g., VRF output or block seed).

## 5. Runtime ABI & Entry Points

The Runtime exposes a minimal, canonical Application Binary Interface (ABI) that the Client invokes to execute blocks and validate state.

| Entry Point | Signature | Description |
| --- | --- | --- |
| `Core_version` | `() -> Version` | Returns the semantic version and spec version of the Runtime. |
| `validate_transaction` | `(tx: Extrinsic) -> Validity` | Checks signature, nonce, and thermodynamic pre-conditions before mempool inclusion. |
| `apply_extrinsic` | `(ext: Extrinsic) -> DispatchOutcome` | Mutates the state and emits verifiable events. |
| `finalize_block` | `() -> Header` | Computes the final state root and Merkle tree commitments. |
| `execute_certificate` | `(cert: ExchangeCert) -> Receipt` | Processes a P2P pairwise exchange and verifies ZK constraints. |
| `validate_thermodynamic_state` | `(state: PhysicalState) -> Result<()>` | Evaluates incoming oracle telemetry against physical limits. |

## 6. DATA Codec Specification (Minimal)

All data crossing the Rust/RISC-V memory boundary uses the DATA Codec, optimized for auditability and zero-copy performance.

- **Canonical Encoding:** Single, unambiguous byte representation for any given value (critical for consistent hashing).
- **Endianness:** Strictly Little-Endian.
- **Anti-DoS Bounds:** Fixed limits on maximum vector lengths and recursion depth during deserialization to prevent memory-exhaustion attacks on the edge device.
- **Compatibility:** Forward and backward compatibility enforced via strict versioning tags in the byte header.

## 7. Physics Firewall Specification

The "Physics Firewall" is a formalized, mathematically verifiable threat model preventing asset degradation.

### 7.1 Minimum Formal Model

The state evaluates the following physical variables:

- **SOC:** State of Charge (e.g., 5% ≤ SOC ≤ 95%)
- **T_cell:** Cell Temperature (e.g., ≤ 45°C)
- **P_charge / P_discharge:** Active Power limits based on dynamic C-rates
- **ΔT/Δt:** Thermal ramp rates

### 7.2 Proof Statement

The Runtime emits a receipt satisfying the following:

- **Statement:** “There exists a private witness *w* (the dispatch trading strategy) such that `R1CS(w, public_inputs) = 0`, where `public_inputs` include cryptographic commitments to the physical telemetry and the manufacturer's thermal envelope.”

### 7.3 Threat Model

- **MarketCo Adversarial:** Cannot force a profitable but damaging dispatch, as the R1CS constraint will fail, rejecting the extrinsic.
- **Asset Operator Adversarial:** Mitigated via hardware-level attestation (TPM) signing the telemetry before entering the Mempool.
- **Node Operator Adversarial:** Cannot alter the Runtime execution without invalidating the Merkle state root.

## 8. Cryptography (Commitments & Proofs)

- **Pedersen Commitments:** Endowments (MWh) and balances are obscured using Curve25519 (Ristretto255 group). Domain separation is strictly enforced for generators G and H using transcript labels.
- **Bulletproofs & R1CS:** Range proofs (to verify limits without revealing exact SOC) and Rank-1 Constraint Systems are utilized. Heavy cryptographic operations are delegated to Client Host Functions to bypass RISC-V cycle limits.
- **Merkleized Commitment Batching:** Pairwise exchange certificates are aggregated into a single verifiable state root (NOMT), optimizing verification cost without compromising the homomorphic properties of the underlying transactions.

## 9. XAM Protocol Overview (Cross-Asset Messaging)

XAM enables trustless coordination between different Runtimes (e.g., Solar Node negotiating with BESS Node).

- **Message Format:** `[Src_Runtime_ID, Dst_Runtime_ID, Nonce, Expiry_Block, Payload_Commitment]`.
- **Delivery & Ordering:** Routed via libp2p `gossipsub`. Strictly ordered by nonce.
- **Replay Protection:** Enforced via destination-side nonce tables and expiry blocks.
- **Atomicity:** Utilizes an optimistic receipt model. If the destination Runtime fails to execute constraints, a failure receipt is generated, triggering a rollback event on the source.

## 10. Operations, Observability & Governance

Infrastructure funds require strict operational guarantees.

- **Observability:** The system guarantees reproducible execution. All extrinsics produce an Event Log Commitment, allowing full historical state reconstruction.
- **Key Management:** Node identity keys and oracle signature keys support secure enclaves (HSM/TPM attestation pipelines).
- **Upgrade Governance:** `set_code` extrinsics (Runtime upgrades) are gated behind strict threshold signature policies (e.g., 3-of-5 multi-sig between IKKUNA, MarketCo, and the Asset Owner). Emergency rollback mechanisms are hardcoded into the Client release.

---

## 11. Module Extension Standard

The ONEDGE-SDK supports pluggable Runtime modules for OEM-specific thermodynamic models. This section introduces the Module Extension Standard and provides normative references; the complete specification is in `MODULES_SPEC.md`.

### 11.1 Purpose

A **Module** is a deterministic RISC-V (`no_std`) state-transition unit that extends the Physics Firewall (§7) for asset-specific computations. Modules allow OEM-specific electrochemical models to be deployed without requiring a full Runtime `spec_version` bump, while remaining universally subject to the Physics Firewall invariants defined in `SECURITY_MODEL.md` §5 and the module-level invariants PF-M1 through PF-M6 defined in `MODULES_SPEC.md` §6.

### 11.2 Core Physical Operators (Normative)

`MODULES_SPEC.md` defines three consensus-critical operators. All are consensus-critical: any change to their semantics, fixed-point formats, or rounding rules MUST bump `spec_version`.

| Operator | Symbol | Format | Purpose |
|---|---|---|---|
| Reaction Operator | `phi` (φ) | Q32.32 accumulator | SOC state update: couples net power with resistive dissipation. |
| Synchrony Coefficient | `psi` (ψ) | Q0.32 normalised ratio | Deviation between GR-committed and BMS-attested SOC. |
| Divergence Proxy | `delta` (δ) | Q16.16 scalar | Bounded thermodynamic stress indicator: thermal headroom + SOC rate. |

### 11.3 Fixed-Point Standard

All module computations MUST use Q16.16 / Q32.32 / Q0.32 fixed-point formats with round-half-to-even rounding and saturation-with-flag semantics, as specified in `MODULES_SPEC.md` §4. Floating-point MUST NOT appear in any consensus-critical path.

### 11.4 Module Registry

Modules MUST be registered on-chain before use. The registry records `module_id` (UUID v5), `code_hash` (BLAKE2b-256), `spec_version_range`, and `invariant_set_hash` (Keccak-256 of the declared invariant set). Invocations of unregistered or version-mismatched modules MUST be rejected.

### 11.5 Normative Reference

> **MUST:** All module implementations MUST comply with `MODULES_SPEC.md` (version 1.1.0-rc3) in its entirety. The LaTeX authoritative canonical is `OnEdge_Modules_Spec_v1.1.0-rc3.tex` (S-axis companion, I-axis 1.1.0-rc3).

### 11.6 New Reason Codes

`MODULES_SPEC.md` §7 introduces reason codes in the range `[0x0200, 0x02FF]`: `ERR_MODULE_UNREGISTERED` (0x0200), `ERR_MODULE_VERSION_MISMATCH` (0x0201), `ERR_MODULE_INVARIANT_HASH_MISMATCH` (0x0202), `ERR_SYNCHRONY_EXCEEDED` (0x0210), `ERR_SATURATION_STICKY` (0x0211). These extend the base codes in `RUNTIME_ABI.md` §2.1.
