# ONEDGE-SDK — Module Extension Specification

**Status:** Draft (Normative)
**Version:** 1.1.0-rc3
**Applies to:** ONEDGE-SDK Runtime, Physics Firewall
**Parent spec:** `SPECIFICATION.md` §7 (Physics Firewall), §11 (Module Extension Standard)
**Canonical reference (authoritative):** `OnEdge_Modules_Spec_v1.1.0-rc3.tex`

---

## Table of Contents

1. [Purpose and Scope](#1-purpose-and-scope)
2. [Normative Language](#2-normative-language)
3. [Module Extension Contract](#3-module-extension-contract)
4. [Fixed-Point Arithmetic Standard](#4-fixed-point-arithmetic-standard)
5. [Core Physical Operators](#5-core-physical-operators)
6. [Physics Firewall Invariants (Module Level)](#6-physics-firewall-invariants-module-level)
7. [Reason Codes (Module Extension)](#7-reason-codes-module-extension)
8. [Conformance](#8-conformance)
9. [References](#9-references)

---

## 1. Purpose and Scope

This document defines:

1. The **Module Extension Contract** — the normative interface every pluggable Runtime module MUST implement to be admitted into the ONEDGE module registry.
2. The **Core Physical Operators** — reaction operator $\varphi$, synchrony coefficient $\psi$, and divergence proxy $\delta$ — with fixed-point formats, rounding rules, and saturation semantics.
   Plain-text equivalents: `phi` (reaction operator / SOC accumulator), `psi` (synchrony coefficient), `delta` (divergence proxy).
3. The **Physics Firewall Invariants at Module Level** (PF-M1 through PF-M6) — the conditions a module MUST preserve across every state step.
4. **Module Conformance Requirements** — what a module MUST expose to qualify for the module registry.

> **Consensus-critical.** All operators, fixed-point formats, rounding modes, and saturation rules defined here are consensus-critical. Any change to their semantics MUST bump the Runtime `spec_version` and MUST be reflected in the manifest compatibility table.

The LaTeX canonical (`OnEdge_Modules_Spec_v1.1.0-rc3.tex`) is the authoritative reference for all mathematical statements. In any conflict between this Markdown and the LaTeX canonical, the LaTeX canonical governs.

---

## 2. Normative Language

The key words **MUST**, **MUST NOT**, **REQUIRED**, **SHALL**, **SHALL NOT**, **SHOULD**, **RECOMMENDED**, **MAY**, and **OPTIONAL** are used as defined in RFC 2119.

---

## 3. Module Extension Contract

### 3.1 Definition

A **Module** is a deterministic state-transition unit compiled to RISC-V (`no_std`) that:

- Is identified by a globally unique `module_id: [u8; 16]` (UUID v5, namespace `ONEDGE-SDK/v1/Module`, name = canonical module name as UTF-8 bytes).
- Implements all normative entry points in §3.2.
- Enforces all Physics Firewall invariants in §6 on every `module_step` invocation.
- Satisfies the determinism requirement in §3.3.

### 3.2 Normative Entry Points

| Entry Point | Signature | Description |
|---|---|---|
| `module_version` | `() -> ModuleVersion` | Returns `{ module_id: [u8;16], spec_version: u32, impl_version: u32, code_hash: [u8;32] }`. |
| `module_step` | `(state: PhysicalState, params: ModuleParams) -> StepReceipt` | Executes one state-transition step. MUST be deterministic. MUST enforce all PF-M invariants. |
| `module_validate` | `(state: PhysicalState, params: ModuleParams) -> Validity` | Pre-flight constraint check. MUST complete in O(1) bounded time (see §3.3 and Invariant I7 in `SECURITY_MODEL.md`). MUST NOT perform ZK proof verification. |
| `module_invariants` | `() -> InvariantSet` | Returns the serialized set of Physics Firewall invariants this module declares. The Keccak-256 of this output MUST equal the `invariant_set_hash` registered in the Module Registry. |

`StepReceipt` MUST include:
- `post_state_commitment: [u8; 32]` — Keccak-256 of the canonical post-state encoding.
- `status: u32` — bitmask; bit 0 = `SATURATED` flag (see §4.3).
- `reason_code: u32` — 0 on success; normative code on failure (see §7).

### 3.3 Determinism Requirement

Modules MUST NOT access wall-clock time, network I/O, filesystem, or nondeterministic RNG. All external inputs MUST flow through `PhysicalState` or `ModuleParams`. This extends Invariant I2 (`SECURITY_MODEL.md` §5) to the module layer.

### 3.4 Module Registration

Before first use, a module MUST be registered in the on-chain Module Registry via a governance-gated `register_module` extrinsic. The registry entry MUST record:

| Field | Type | Requirement |
|---|---|---|
| `module_id` | `[u8; 16]` | Unique UUID v5. |
| `code_hash` | `[u8; 32]` | BLAKE2b-256 of the compiled RISC-V blob. |
| `spec_version_range` | `(u32, u32)` | `[min, max]` Runtime `spec_version` compatibility. |
| `invariant_set_hash` | `[u8; 32]` | Keccak-256 of the serialized `InvariantSet` returned by `module_invariants`. |
| `canonical_name` | UTF-8 string, ≤ 64 bytes | Human-readable identifier. |

A Runtime MUST reject extrinsics invoking an unregistered module (`ERR_MODULE_UNREGISTERED`) or a module whose `spec_version` is outside the active Runtime `spec_version` (`ERR_MODULE_VERSION_MISMATCH`).

---

## 4. Fixed-Point Arithmetic Standard

All physical operators defined in §5 use fixed-point arithmetic. Floating-point MUST NOT appear in any consensus-critical computation path.

### 4.1 Format Definitions

| Symbol | Format | Sign | Integer bits | Fractional bits | Range | Resolution | Primary Use |
|---|---|---|---|---|---|---|---|
| Q16 | Q16.16 | signed | 16 | 16 | ±32 767.99998 | ~1.526 × 10⁻⁵ | SOC, temperatures, dimensionless ratios |
| Q32 | Q32.32 | signed | 32 | 32 | ±2.147 × 10⁹ | ~2.328 × 10⁻¹⁰ | Energy accumulators, long integrations |
| Q0 | Q0.32 | unsigned | 0 | 32 | [0, 1) | 2⁻³² ≈ 2.328 × 10⁻¹⁰ | Normalized ratios (e.g., ψ) |

Plain-text format notation: `Q16 = s[15:0].f[15:0]`, `Q32 = s[31:0].f[31:0]`, `Q0 = 0.f[31:0]`.

Constant `Q16_ONE = 0x0001_0000` (represents 1.0 in Q16).
Constant `Q32_ONE = 0x0000_0001_0000_0000` (represents 1.0 in Q32).
Constant `Q0_ONE  = 0xFFFF_FFFF` (represents 1.0 − 2⁻³² in Q0, the maximum representable value).

### 4.2 Rounding Mode

**Round-half-to-even** (banker's rounding, IEEE 754 default rounding mode) MUST be applied at every fractional truncation step — that is, whenever a multi-word intermediate result is narrowed to the target format by discarding low-order bits.

Plain-text rule: let `r` be the bits to be discarded. If the most-significant discarded bit is 0, truncate. If it is 1 and any remaining discarded bits are non-zero, round up. If it is 1 and all remaining discarded bits are 0 (exact half), round to even (round up iff the last retained bit is 1).

### 4.3 Saturation Semantics

On overflow or underflow, an implementation MUST **saturate** (clamp to the format's maximum or minimum representable value) rather than wrap. Saturation MUST atomically set bit 0 (`SATURATED`) in the `StepReceipt.status` word. The `SATURATED` flag MUST be propagated into the Golden Record event commitment for that step.

Once `SATURATED` is set, a module MUST reject subsequent `module_step` calls with `ERR_SATURATION_STICKY` until an authorized operator-clearance extrinsic resets the flag (see PF-M6 in §6).

---

## 5. Core Physical Operators

### 5.1 Reaction Operator (phi / φ)

**Purpose:** Computes the incremental SOC update for one dispatch step, coupling electrochemical inventory draw-down with resistive losses.

**Mathematical statement (LaTeX canonical §4.1):**

```
phi_{k+1} = phi_k + Delta_phi_k

Delta_phi_k = (P_net_k - R_eq(T_k, SOC_k) * I_k^2) * Delta_t
```

where `phi` is the SOC accumulator (Q32), `P_net` is net power (Q16, signed, in per-unit of nominal capacity), `R_eq(T, SOC)` is the equivalent series resistance lookup (Q16), `I_k` is the instantaneous current (Q16), and `Delta_t` is the fixed step duration in seconds (Q16 constant, see `PARAMETERS.md` §2).

**Fixed-point procedure (normative):**

1. Load `phi_k` as Q32 from state.
2. Read `P_net_k` as Q16 (signed) from `PhysicalState`.
3. Look up `R_eq(T_k, SOC_k)` as Q16 from the piecewise-linear table in `PARAMETERS.md` §3. Interpolation MUST use Q32 intermediate products with round-half-to-even truncation.
4. Read `I_k` as Q16 from `PhysicalState`. Compute `I_k^2` as Q32 by multiplying two Q16 values and right-shifting by 16 (with round-half-to-even).
5. Compute `R_eq * I_k^2` as Q32 (multiply Q16 × Q32; right-shift result by 16).
6. Compute `Delta_phi_k` as Q32: `(P_net_k_q32 - R_eq_I_sq_q32) * DELTA_T_Q16 >> 16`.
7. Accumulate: `phi_{k+1}_q32 = phi_k_q32 + Delta_phi_k_q32` using saturating Q32 addition.
8. Clamp: if `phi_{k+1}` < `SOC_MIN_Q32` or > `SOC_MAX_Q32` (constants in `PARAMETERS.md` §2), saturate and set `SATURATED` flag.
9. If pre-clamp value was out of bounds, emit `ERR_SOC_OUT_OF_BOUNDS` and abort step (do not write post-state).

**Conformance fixture:** `conformance-vectors/modules-1.1.0-rc3/phi_step.json` (to be published in Move 2).

### 5.2 Synchrony Coefficient (psi / ψ)

**Purpose:** Measures the normalized deviation between the GR-committed SOC and the BMS-attested physical measurement. Zero = perfect synchrony; approaching 1 = maximum permissible divergence.

**Mathematical statement (LaTeX canonical §4.2):**

```
psi_k = |phi_committed_k - phi_physical_k| / (SOC_MAX - SOC_MIN)
```

where `phi_committed_k` is the SOC from the current-period Golden Record public inputs vector (Q32), and `phi_physical_k` is the BMS-attested telemetry value (Q32).

**Fixed-point procedure (normative):**

1. Read `phi_committed_k` as Q32 from the GR public inputs vector (`gr_public_inputs` label, `CRYPTO_DOMAINS.md` §3).
2. Read `phi_physical_k` as Q32 from the attested telemetry extrinsic.
3. Compute absolute difference: `d_k = |phi_committed_k - phi_physical_k|` as Q32 (unsigned; take two's-complement absolute value).
4. Compute the denominator constant `RANGE_Q32 = SOC_MAX_Q32 - SOC_MIN_Q32` (from `PARAMETERS.md` §2; evaluated once at module initialization).
5. Compute `psi_k` as Q0: perform `(d_k << 32) / RANGE_Q32` using 128-bit intermediate (or equivalent shift-and-divide), truncate to 32 bits with round-half-to-even.
6. If `d_k >= RANGE_Q32`, saturate `psi_k` to `Q0_ONE` (0xFFFF_FFFF) and set `SATURATED` flag.
7. If `psi_k > PSI_MAX_Q0` (from `PARAMETERS.md` §2), emit `ERR_SYNCHRONY_EXCEEDED` and abort step.

**Conformance fixture:** `conformance-vectors/modules-1.1.0-rc3/psi_step.json` (to be published in Move 2).

### 5.3 Divergence Proxy (delta / δ)

**Purpose:** A computationally bounded scalar indicator of thermodynamic divergence from the nominal operating envelope, combining thermal headroom and SOC rate-of-change without requiring full ODE integration.

**Mathematical statement (LaTeX canonical §4.3):**

```
delta_k = alpha * (T_cell_k - T_amb_k) / T_HEADROOM
        + (1 - alpha) * |DSOC_k| / DSOC_MAX
```

where `alpha` is the thermal weighting coefficient (Q16, in `PARAMETERS.md` §2), `T_HEADROOM = T_CELL_MAX - T_CELL_NOM` (Q16, `PARAMETERS.md` §2), and `DSOC_k = phi_k - phi_{k-1}` (Q16, derived from Q32 difference right-shifted by 16).

**Fixed-point procedure (normative):**

1. Compute `T_diff_k = T_cell_k - T_amb_k` as Q16 (signed, Celsius).
2. Compute term1: `T_diff_k * Q16_ONE / T_HEADROOM_Q16` — perform as `(T_diff_k << 16) / T_HEADROOM_Q16` using 64-bit intermediate; truncate to Q16 with round-half-to-even. Clamp to [0, Q16_ONE].
3. Compute `DSOC_k_q32 = phi_k - phi_{k-1}` as Q32. Derive Q16 magnitude: `|DSOC_k_q16| = |DSOC_k_q32| >> 16` (right-shift, with round-half-to-even on the discarded 16 bits).
4. Compute term2: `|DSOC_k_q16| * Q16_ONE / DSOC_MAX_Q16` — 64-bit intermediate; truncate to Q16. Clamp to [0, Q16_ONE].
5. Compute weighted sum: `delta_k = (ALPHA_Q16 * term1 + (Q16_ONE - ALPHA_Q16) * term2) >> 16`. Use 64-bit intermediates for each product; truncate each to Q16 before summing to avoid overflow.
6. Clamp `delta_k` to `[0, Q16_ONE]`; set `SATURATED` flag if clamped from above.
7. If `delta_k > DELTA_MAX_Q16` (from `PARAMETERS.md` §2), emit `ERR_THERMAL_VIOLATION` and abort step.

**Conformance fixture:** `conformance-vectors/modules-1.1.0-rc3/delta_step.json` (to be published in Move 2).

---

## 6. Physics Firewall Invariants (Module Level)

Every module MUST enforce all of the following invariants on every `module_step` call. A violation MUST cause the step to abort (no state written), return the corresponding reason code, and NOT set `SATURATED` (saturation is a distinct bounded-overflow condition, not a constraint violation).

| Invariant | Condition (plain text) | Condition (Q-format) | Reason Code |
|---|---|---|---|
| **PF-M1** SOC Bounds | SOC_MIN ≤ phi_{k+1} ≤ SOC_MAX | `SOC_MIN_Q32 <= phi_k1_q32 <= SOC_MAX_Q32` | `ERR_SOC_OUT_OF_BOUNDS` |
| **PF-M2** Thermal Ceiling | T_cell_k ≤ T_CELL_MAX | `T_cell_q16 <= T_CELL_MAX_Q16` | `ERR_THERMAL_VIOLATION` |
| **PF-M3** Thermal Ramp Rate | \|P_k − P_{k−1}\| ≤ RAMP_MAX · Δt | `abs(P_k_q16 - P_prev_q16) <= RAMP_MAX_Q16 * DELTA_T_Q16 >> 16` | `ERR_THERMAL_VIOLATION` |
| **PF-M4** Synchrony Bound | psi_k ≤ PSI_MAX | `psi_k_q0 <= PSI_MAX_Q0` | `ERR_SYNCHRONY_EXCEEDED` |
| **PF-M5** Divergence Bound | delta_k ≤ DELTA_MAX | `delta_k_q16 <= DELTA_MAX_Q16` | `ERR_THERMAL_VIOLATION` |
| **PF-M6** Saturation Clearance | If prior StepReceipt.status bit 0 = SATURATED, module_step MUST be blocked until operator-clearance extrinsic | `status & 0x01 == 0` | `ERR_SATURATION_STICKY` |

PF-M1 through PF-M5 are evaluated in order within a single `module_step` call. Evaluation MUST short-circuit on the first violated invariant — subsequent invariants MUST NOT be evaluated once a violation is detected (to preserve bounded execution cost, Invariant I7).

These module-level invariants extend and refine Invariant I4 (Physics Firewall Invariant) in `SECURITY_MODEL.md` §5.

---

## 7. Reason Codes (Module Extension)

The following reason codes are normatively introduced by this specification and extend the base set defined in `RUNTIME_ABI.md` §2.1. Implementations MUST map module failures to exactly one of these codes or the base codes from `RUNTIME_ABI.md`.

| Code | Numeric ID | Meaning |
|---|---|---|
| `ERR_MODULE_UNREGISTERED` | 0x0200 | Module ID not present in the on-chain Module Registry. |
| `ERR_MODULE_VERSION_MISMATCH` | 0x0201 | Module `spec_version` outside the active Runtime `spec_version` compatibility range. |
| `ERR_MODULE_INVARIANT_HASH_MISMATCH` | 0x0202 | `module_invariants()` output hash does not match the registered `invariant_set_hash`. |
| `ERR_SYNCHRONY_EXCEEDED` | 0x0210 | Synchrony coefficient psi_k exceeds `PSI_MAX_Q0`. |
| `ERR_SATURATION_STICKY` | 0x0211 | `SATURATED` flag is set in prior StepReceipt; `module_step` is blocked pending operator clearance. |

Numeric IDs in range `[0x0200, 0x02FF]` are reserved for module-extension reason codes under this specification.

---

## 8. Conformance

A module is **MODULES-SPEC-1.1.0-rc3 conformant** if and only if:

1. **Entry points:** All four entry points in §3.2 are implemented with correct signatures.
2. **Fixed-point:** All operators use Q16/Q32/Q0 formats, round-half-to-even, and saturation-with-flag as specified in §4.
3. **Invariant enforcement:** All six PF-M invariants are enforced in order with short-circuit evaluation on every `module_step` call.
4. **Reason codes:** All reason codes in §7 (plus applicable base codes from `RUNTIME_ABI.md`) are emitted as specified.
5. **Registry:** The module is registered with a valid `invariant_set_hash` matching the output of `module_invariants()`.
6. **Vectors:** The module passes all fixtures in `conformance-vectors/modules-1.1.0-rc3/` when published (Move 2 of the suite roadmap).

Conformance testing is the responsibility of the module author. StandardCo MAY operate a conformance test runner as part of the module registry admission process.

---

## 9. References

- `SPECIFICATION.md` §7 (Physics Firewall — parent definition), §11 (Module Extension Standard — this document)
- `RUNTIME_ABI.md` §2.1 (Base reason codes, Bounded-Cost Invariant I7)
- `SECURITY_MODEL.md` §5 (Security Invariants I2, I4, I7)
- `CRYPTO_DOMAINS.md` §3 (Commitment generators and transcript labels)
- `XAM.md` §5 (Atomicity and failure receipt semantics)
- `PARAMETERS.md` (All named constants: SOC_MIN/MAX, T_CELL_MAX, RAMP_MAX, PSI_MAX, DELTA_MAX, ALPHA, T_HEADROOM, DSOC_MAX, DELTA_T — to be published in Move 3)
- `OnEdge_Modules_Spec_v1.1.0-rc3.tex` (LaTeX authoritative canonical — this session)
- `conformance-vectors/modules-1.1.0-rc3/` (Conformance fixtures — to be published in Move 2)
- `OnEdge_Energy_SpecHardening_v0.0.4.tex` (S-0.0.4 — Physics Firewall baseline)
- `ecme_v0_2_final_with_refs_updated.tex` (ECME-0.2.0 — reaction-diffusion model source)
